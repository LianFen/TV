package com.example.administrator.diandiantv;

import static org.junit.Assert.*;

public class LiveActivityTest {

}